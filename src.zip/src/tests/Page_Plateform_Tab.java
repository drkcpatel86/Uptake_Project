package tests;


import java.util.concurrent.TimeUnit;



import org.junit.Assert;

import tests.testBase;

public class Page_Plateform_Tab extends testBase{
	

	
	public static void Displays_Introtitle_PlateformTabe(){
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getObject("Intro").isDisplayed();
		getObject("Intro").click();
		String intro = getObject("Intro").getText();
		System.out.println(intro);
		Assert.assertTrue(intro.contains("Intro"));
				
	}
	
	public static void GenerationTitle_Displays_PlateformTabe(){
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getObject("Generation").isEnabled();
		getObject("Generation").isDisplayed();
		getObject("Generation").click();
		String Generation = getObject("Generation").getText();
		System.out.println(Generation);	
		Assert.assertTrue(Generation.contains("Generation"));
				
	}
	
	public static void Normalization_Displays_PlateformTabe(){
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getObject("Normalization").isEnabled();
		getObject("Normalization").isDisplayed();
		getObject("Normalization").click();
		String Normalization = getObject("Normalization").getText();
		System.out.println(Normalization);	
		Assert.assertTrue(Normalization.contains("Normalization"));
				
	}
	public static void Storage_Displays_PlateformTabe(){
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getObject("Storage").isEnabled();
		getObject("Storage").isDisplayed();
		getObject("Storage").click();
		String Storage = getObject("Storage").getText();
		System.out.println(Storage);	
		Assert.assertTrue(Storage.contains("Storage"));
				
	}
	
	
}
 	