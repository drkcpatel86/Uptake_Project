package tests;

import java.util.concurrent.TimeUnit;



import org.junit.Assert;

import tests.testBase;

public class Page_Solutions_Tab extends testBase{
	

	
	public static void CondBasedMonitoring_Displays_SolutionsTab(){
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getObject("CondBasedMonitoring").isDisplayed();
		getObject("CondBasedMonitoring").click();
		String CondBasedMonitoring = getObject("CondBasedMonitoring").getText();
		System.out.println(CondBasedMonitoring);
		Assert.assertTrue(CondBasedMonitoring.contains("Condition-Based Monitoring"));
		String CondBasedMonitoring_Description = getObject("CondBasedMonitoring_Description").getText();
		Assert.assertTrue(CondBasedMonitoring_Description.contains("Track real-time measurements from thousands of high-value assets across your industrial ecosystem. Understand each asset�s health status and location in every corner of the globe and make informed decisions about how and when they are maintained, using the world�s most intuitive industrial analytics and visualization platform."));
		System.out.println(CondBasedMonitoring_Description);
					
	}
	
	public static void PlannigAndForecasting_Displays_SolutionsTab(){
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		getObject("PlannigAndForecasting").isDisplayed();
		getObject("PlannigAndForecasting").click();
		String PlannigAndForecasting = getObject("PlannigAndForecasting").getText();
		System.out.println(PlannigAndForecasting);
		Assert.assertTrue(PlannigAndForecasting.contains("Planning and Forecasting"));
		String PlanningAndForecasting_Description = getObject("PlanningAndForecasting_Description").getText();
		Assert.assertTrue(PlanningAndForecasting_Description.contains("Create optimal operation plans based on performance data and schedule recovering strategies to minimize operational disruptions due to unforeseen events. Improve forecasting to ensure that parts and equipment are available when needed, minimizing unscheduled downtime."));
		System.out.println(PlanningAndForecasting_Description);
	}
	
	public static void FuelAndEnergy_Displays_SolutionsTab(){
		System.out.println("Fuel and Energy Validation is under maintance");
	}
	
	public static void SupplyChainOptimization_Displays_SolutionsTab(){
		System.out.println("Supply Chain Maintenance Validation is under maintance");
	}
	
}
 	