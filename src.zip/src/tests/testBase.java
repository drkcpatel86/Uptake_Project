package tests;

import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.NoSuchElementException;

import datatable.Xls_Reader;
import util.TestUtil;
import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


import java.net.URL;
public class testBase {
	
	// initializing properties file , reading property file 
	
	
	public static Properties CONFIG=null;
	public static Properties OR=null;
	public static WebDriver dr=null;
	public static RemoteWebDriver remoteDriver=null;
	public static EventFiringWebDriver driver=null;

	public static boolean isLoggedIn=false;
	public static Xls_Reader datatable=null;
	public static final String URL = "http://hub.browserstack.com/wd/hub";
	
	
	public static void initialize() throws IOException{
		
		System.out.println("initialse class called");
		CONFIG= new Properties();
		FileInputStream fn =new FileInputStream(System.getProperty("user.dir")+"//src//config/config.properties");
		CONFIG.load(fn);
		// OR Properties
		OR= new Properties();
		fn =new FileInputStream(System.getProperty("user.dir")+"//src//config/OR.properties");
		OR.load(fn);
		if (CONFIG.getProperty("browser").equals("BrowserStack")){
			System.out.println("BrowserStack initialized");
		    DesiredCapabilities caps = new DesiredCapabilities();
		    caps.setCapability("browserstack.user", "gracetolan1");
		    caps.setCapability("browserstack.key", "Cy5XzKx9s6JZz2jos8VD");
		    caps.setCapability("browser", "IE");
		    caps.setCapability("browser_version", "9.0");
		    caps.setCapability("os", "Windows");
		    caps.setCapability("os_version", "7");
		    caps.setCapability("resolution", "1024x768");
		    caps.setCapability("browserstack.debug", "true");
		    caps.setCapability("browserstack.local", "true");
		    
		    dr = new RemoteWebDriver(new URL(URL), caps);	
		}
		 
	/*if(driver == null && !CONFIG.getProperty("browser").equals("BrowserStack")){
		System.out.println("second");
//		// config property file
//		CONFIG= new Properties();
//		FileInputStream fn =new FileInputStream(System.getProperty("user.dir")+"//src//config/config.properties");
//		CONFIG.load(fn);
//		// OR Properties
//		OR= new Properties();
//		fn =new FileInputStream(System.getProperty("user.dir")+"//src//config/OR.properties");
//		OR.load(fn);
//		// Initalize the webdriver and EventFiringWebDriver      */
		if(CONFIG.getProperty("browser").equals("Firefox")){
			 dr = new FirefoxDriver();
			 dr.manage().window().maximize();
			 System.out.println("launching tests in Firefox");
		}
		
		else if(CONFIG.getProperty("browser").equals("InternetFlex")){
			System.setProperty("webdriver.ie.driver",  "C:\\Users\\Patelk\\Downloads\\IEDriverServer_Win32_2.53.1\\IEDriverServer.exe");
			dr= new InternetExplorerDriver();
			dr.manage().window().setSize(new Dimension(1024, 768));
			 System.out.println("launching tests in IE");
			
		}
		else if(CONFIG.getProperty("browser").equals("IE")){
			System.setProperty("webdriver.ie.driver",  (System.getProperty("user.dir")+"//IEDriverServer.exe"));
			dr = new InternetExplorerDriver();
			dr.manage().window().maximize();
			 System.out.println("launching tests in IE");  
		}
		else if(CONFIG.getProperty("browser").equals("Chrome")){
			System.setProperty("webdriver.chrome.driver", (System.getProperty("user.dir")+"//chromedriver.exe"));
			 dr = new ChromeDriver();
			 dr.manage().window().setSize(new Dimension(1024, 768));
		//	 dr.manage().window().maximize();
			 System.out.println("launching tests in Chrome");
		}
	
	
	 driver = new EventFiringWebDriver(dr);
	 driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	 
	 datatable = new Xls_Reader (System.getProperty("user.dir")+"//src//config//Suite1.xlsx");
	}
	



	public static WebElement getObject(String xpathKey) {
		try{
			return driver.findElement(By.xpath(OR.getProperty(xpathKey)));
		}catch(Throwable t){
			// report error
			TestUtil.takeScreenShot(xpathKey);
			Assert.assertTrue(t.getMessage(),false);
			
			return null;
		}
		
	}



	public static WebElement CSS_Object(String xpathKey) {
		try{
			return driver.findElement(By.cssSelector(OR.getProperty(xpathKey)));
		}catch(Throwable t){
			// report error
			TestUtil.takeScreenShot(xpathKey);
			Assert.assertTrue(t.getMessage(),false);
			
			return null;
		}
		
	}
	
	public static void Hover(WebDriver driver, WebElement element){
		Actions action = new Actions(driver);
		action.moveToElement(element).perform();
	}
	
	
	public static void HoverAndClick(WebDriver Driver, WebElement elementToHover, WebElement elementToClick){
		
		Actions action = new Actions(driver);
		action.moveToElement(elementToHover).click(elementToClick).build().perform();
	}
	
	public static boolean isElementPresent(By locatorKey) {
	    try {
	        driver.findElement(locatorKey);
	        return true;
	    } catch (org.openqa.selenium.NoSuchElementException e) {
	        return false;
	    }
	}

	public static String getCurrentTimeStamp() {
	    return new SimpleDateFormat("_yyyy_MM_dd_HH_mm_ss_SSS").format(new Date());
	}
	
}



