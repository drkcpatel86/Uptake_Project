package util;

import java.io.File;
import java.util.Date;
import java.util.*;
import java.io.*;
import java.*;
import java.util.Date;
import java.text.DateFormat;
import java.text.Format;
import java.text.SimpleDateFormat;


public class rename_currentdate {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
	    File file = new File("c:\\Report_PressGaney");
	    
        Date date = new Date();

        Format formatter = new SimpleDateFormat("YYYY-MM-dd_hh-mm-ss");
   //     outFile = new PrintWriter(new FileWriter("simplex_" + formatter.format(date) + ".txt"))
	    
	    file.renameTo(new File("c:\\Dr.Patel Dev" + formatter.format(date)));

	}

}
