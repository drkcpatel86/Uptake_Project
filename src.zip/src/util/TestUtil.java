package util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import datatable.Xls_Reader;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;

import tests.testBase;

public class TestUtil extends testBase{
	

	    public static void logout(){
	    	if(isLoggedIn){
	    		getObject("signout_link").click();
	    	}
	    }
	public static  boolean isSkip(String testCase){
		for(int rowNum=2; rowNum<=datatable.getRowCount("Tests"); rowNum++){
			 if(testCase.equals((datatable.getCellData("Tests", "TCID", rowNum)))){
				if(datatable.getCellData("Tests", "Runmode", rowNum).equals("Y"))
					  return false;
				else
					return true; 
			 }
		 }
	   return false;
	
	}
	
	public static Object[][] getData(String testName){
		// return test data;
		// read test data from xls
		if(datatable == null){
			// load the suite 1 sheet
			datatable = new Xls_Reader(System.getProperty("user.dir")+"//src//config//Suite1.xlsx");
			
		}
		
		int rows=datatable.getRowCount(testName)-1;
		if(rows <=0){
			Object[][] testData =new Object[1][0];
			return testData;
			
		}
	    rows = datatable.getRowCount(testName);  // 3
		int cols = datatable.getColumnCount(testName);
		System.out.println("Test Name -- "+testName);
		System.out.println("total rows -- "+ rows);
		System.out.println("total cols -- "+cols);
		Object data[][] = new Object[rows-1][cols];
		
		for(int rowNum = 2 ; rowNum <= rows ; rowNum++){
			
			for(int colNum=0 ; colNum< cols; colNum++){
				data[rowNum-2][colNum]=datatable.getCellData(testName, colNum, rowNum);
			}
		}
		
		return data;
		
	}
	public static void login(){
		File src=new File(System.getProperty("user.dir")+"//src//config//Suite1.xlsx");
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(src);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		XSSFWorkbook wb = null;
		try {
			wb = new XSSFWorkbook(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		XSSFSheet sheet2= wb.getSheetAt(1);  //selecting 2nd sheet
		
		String username= sheet2.getRow(1).getCell(1).getStringCellValue();
		System.out.println(username);
		
		String password=sheet2.getRow(1).getCell(2).getStringCellValue();
		
		getObject("username_signin").sendKeys(username);
		getObject("password_signin").sendKeys(password);
		getObject("submit").click();
	
		
	}
	
	public static void takeScreenShot(String fileName) {
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	    try {
			FileUtils.copyFile(scrFile, new File(System.getProperty("user.dir")+"\\screenshots\\"+fileName+".jpg"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	   
	    
	}

	



// make zip of reports
public static void zip(String filepath){
 	try
 	{
 		File inFolder=new File(filepath);
 		File outFolder=new File("Reports.zip");
 		ZipOutputStream out = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(outFolder)));
 		BufferedInputStream in = null;
 		byte[] data  = new byte[1000];
 		String files[] = inFolder.list();
 		for (int i=0; i<files.length; i++)
 		{
 			in = new BufferedInputStream(new FileInputStream
 			(inFolder.getPath() + "/" + files[i]), 1000);  
 			out.putNextEntry(new ZipEntry(files[i])); 
 			int count;
 			while((count = in.read(data,0,1000)) != -1)
 			{
 				out.write(data, 0, count);
 			}
 			out.closeEntry();
}
out.flush();
out.close();
 	
}
catch(Exception e)
{
  e.printStackTrace();
} 
}	
}
 	