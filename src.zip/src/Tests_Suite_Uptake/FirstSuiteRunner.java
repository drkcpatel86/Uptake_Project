package Tests_Suite_Uptake;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;


@RunWith(Suite.class)
@SuiteClasses({
Plateform_Tab_Page.class,
Solutions_tab_Page.class,
Navigating_All_tabs.class,
})
public class FirstSuiteRunner {

}