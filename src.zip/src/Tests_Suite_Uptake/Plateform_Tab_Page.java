package Tests_Suite_Uptake;


import java.io.IOException;

import org.junit.Assume;
import org.junit.BeforeClass;
import org.junit.Test;
import org.testng.annotations.AfterTest;

import tests.testBase;
import util.TestUtil;

public class Plateform_Tab_Page extends testBase{
	
	@BeforeClass
	public static void beforeTest() throws IOException, Throwable{
		initialize();
		if(TestUtil.isSkip("Plateform_Tab_Page"))
			Assume.assumeTrue(false);
		driver.get(CONFIG.getProperty("testSiteName"));
		Thread.sleep(5000L);
		System.out.println("able to load site" + getCurrentTimeStamp());
		getObject("Pateform_Tab").click();
		TestUtil.takeScreenShot("able to load site and Navigating to Plateform tab" + getCurrentTimeStamp());
	}

	@Test
	public void Validate_IntroTitle_Displays_PlateformTabe() throws InterruptedException{
		
		tests.Page_Plateform_Tab.Displays_Introtitle_PlateformTabe();
		System.out.println("User is able to call property of Plateform");
			
	}
	@Test
	public void Validate_GenerationTitle_Displays_PlateformTabe() throws InterruptedException{
		
		tests.Page_Plateform_Tab.GenerationTitle_Displays_PlateformTabe();
		System.out.println("User is able to call property of Generation");
		
	}
	@Test
	public void Validate_NormalizationTitle_Displays_PlateformTabe() throws InterruptedException{
		
		tests.Page_Plateform_Tab.Normalization_Displays_PlateformTabe();
		System.out.println("User is able to call property of Normalization");
		
	}
	@Test
	public void Validate_StorageTitle_Displays_PlateformTabe() throws InterruptedException{
		
		tests.Page_Plateform_Tab.Storage_Displays_PlateformTabe();
		System.out.println("User is able to call property of Storage");
		
	}
	@AfterTest
	
	public void Closingbrower(){
	System.out.println("User is able to validate navigation functionality between all Tabs successfully");	
	driver.close();
	}

	}
