package Tests_Suite_Uptake;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

import tests.testBase;
import util.TestUtil;


public class Navigating_All_tabs extends testBase{
	
	@BeforeClass
	public static void beforeTest() throws IOException, Throwable{
		//xlsx file 
		initialize();
		if(TestUtil.isSkip("Navigating_All_tabs"))
			Assume.assumeTrue(false);
		driver.get(CONFIG.getProperty("testSiteName"));
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		getObject("Soltuion_Tab").click();
		TestUtil.takeScreenShot("able to load site and Navigating to Solutions tab" + getCurrentTimeStamp());
	}

	@Test
	public void Validate_Navigation_FromSolutions_To_Plateform() throws InterruptedException{
		getObject("Pateform_Tab").click();

		tests.Page_Plateform_Tab.Displays_Introtitle_PlateformTabe();
		System.out.println("User is able to switch tab from Solutions tab to Plateform tab and able to validate Intro title");
		
		tests.Page_Plateform_Tab.GenerationTitle_Displays_PlateformTabe();
		System.out.println("User is able to switch tab from Solutions tab to Plateform tab and able to validate Generation title");
	}
	@Test
	public void Validate_Navigation_FromPlateformTab_to_SoltionsTab() throws InterruptedException{
		getObject("Soltuion_Tab").click();
		System.out.println("User is able to switch to Solutions Tab");
		tests.Page_Solutions_Tab.FuelAndEnergy_Displays_SolutionsTab();
		System.out.println("User is able to switch from plateform tab to solutions tab and able validate Fuel and Energy title");
		tests.Page_Solutions_Tab.CondBasedMonitoring_Displays_SolutionsTab();
		System.out.println("User is able to switch from plateform tab to solutions tabe and able to validate Condition Based monitoring title");
		
		
	}
	
	@Test
	public void Validate_Navigation_from_PlateformTab_to_ApproachTab() throws InterruptedException{
		
		getObject("Uptake_Tab_Approach").click();
		System.out.println("User is able to switch to Tab Approach");
		
	}
	
	@Test
	public void Validate_Navigation_From_TabAppraoch_To_TabPeople() throws InterruptedException{
		
		getObject("Uptake_Tab_People").click();
		System.out.println("User is able to switch to Tab People");
		
	}

	@Test
	public void Validate_Navigation_From_TabPeople_To_TabJoinUs() throws InterruptedException{
		
		getObject("Uptake_Tab_JoinUs").click();
		System.out.println("User is able to switch to Tab JoinUs");
		driver.navigate().back();
		
	}
	@Test
	public void Validate_Navigation_From_TabPeople_To_TabContactUs() throws InterruptedException{
		
		getObject("Uptake_Tab_ContactUs").click();
		System.out.println("User is able to switch to Tab ContactUs");
		driver.navigate().back();
		
	}
	
	@Test
	public void Validate_Navigation_From_ContactUs_To_Blog() throws InterruptedException{
		
		getObject("Uptake_Tab_Blog").click();
		System.out.println("User is able to switch to Tab Blog");
		driver.navigate().back();
		
	}
	@Test
	public void Validate_Navigation_From_Blog_To_UptakeHome() throws InterruptedException{
		
		System.out.println("User is able to switch to Tab Uptake Home");
		driver.navigate().back();
	}
		
	@AfterTest
	
	public void Closingbrower(){
	System.out.println("User is able to validate navigation functionality between all Tabs successfully");	
	driver.close();
	}

	}
