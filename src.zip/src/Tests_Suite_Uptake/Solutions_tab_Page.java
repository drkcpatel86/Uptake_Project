package Tests_Suite_Uptake;


import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.junit.Assume;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;

import tests.testBase;
import util.TestUtil;

public class Solutions_tab_Page extends testBase{
	
	@BeforeClass
	public static void beforeTest() throws IOException, Throwable{
		//xlsx file 
		initialize();
		if(TestUtil.isSkip("Solutions_tab_Page"))
			Assume.assumeTrue(false);
		driver.get(CONFIG.getProperty("testSiteName"));
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("able to load site" + getCurrentTimeStamp());
		getObject("Soltuion_Tab").click();
		TestUtil.takeScreenShot("able to load site and Navigating to Solutions tab" + getCurrentTimeStamp());
	}

	@Test
	public void Validate_CondBasedMonitoring_Displays_SolutionsTab() throws InterruptedException{
		
		tests.Page_Solutions_Tab.CondBasedMonitoring_Displays_SolutionsTab();
		
	}
	@Test
	public void Validate_PlanningAndForecasting_Displays_SolutionsTab() throws InterruptedException{
		
		tests.Page_Solutions_Tab.PlannigAndForecasting_Displays_SolutionsTab();
		
	}

	@Test
	public void Validate_FuelAndEnergy_Displays_SolutionsTab() throws InterruptedException{
		
		tests.Page_Solutions_Tab.FuelAndEnergy_Displays_SolutionsTab();
		
	}
	@Ignore
	@Test
	public void Validate_SupplyChainOptimization_Displays_SolutionsTab() throws InterruptedException{
		
		tests.Page_Solutions_Tab.SupplyChainOptimization_Displays_SolutionsTab();
		
	}	

	@AfterTest
	
	public void Closingbrower(){
	System.out.println("User is able to validate navigation functionality between all Tabs successfully");	
	driver.close();
	}
	
	}
